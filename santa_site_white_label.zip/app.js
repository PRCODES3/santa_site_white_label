
console.log("White-label merged app loaded.");
